﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

sealed class ReleaseInfo {
 public string Tag,VersionText,Notes,Page,Name,Download,Sha256,ChecksumUrl;
 public long Size;
 public Version Version;
 public bool Newer{get{return Version>UpdateService.Current;}}
 public bool CanInstall{get{return Newer&&!string.IsNullOrEmpty(Download)&&Size>0;}}
}
static class UpdateService {
 public const string Repo="https://github.com/relsx/feng-c-practice",Api="https://api.github.com/repos/relsx/feng-c-practice/releases/latest";
 public static readonly Version Current=new Version(1,2,1,2);
 public static ReleaseInfo Latest{get;private set;}
 public static string Status="尚未检查更新";
 public static bool Checking{get;private set;}
 public static DateTime CheckedAt{get;private set;}
 public static event Action Changed;
 static Task currentCheck;static readonly object gate=new object();
 static readonly JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=2097152};
 public static string Root{get{return Path.Combine(Engine.DataRoot,"updates");}}
 public static bool TryVersion(string tag,out Version version){version=null;var m=Regex.Match(tag??"",@"^(?:ver|v)?(\d+)\.(\d+)(?:\.(\d+))?(?:\.(\d+))?$",RegexOptions.IgnoreCase);int a,b,c=0,d=0;if(!m.Success||!int.TryParse(m.Groups[1].Value,out a)||!int.TryParse(m.Groups[2].Value,out b)||m.Groups[3].Success&&!int.TryParse(m.Groups[3].Value,out c)||m.Groups[4].Success&&!int.TryParse(m.Groups[4].Value,out d))return false;version=new Version(a,b,c,d);return true;}
 static string S(IDictionary<string,object> a,string k){object v;return a.TryGetValue(k,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):"";}
 public static ReleaseInfo Parse(string raw){var a=json.Deserialize<Dictionary<string,object>>(raw);if(a==null)throw new InvalidDataException("版本信息为空。");if(S(a,"draft")=="True"||S(a,"prerelease")=="True")throw new InvalidDataException("忽略草稿或预发布版本。");Version v;string tag=S(a,"tag_name");if(!TryVersion(tag,out v))throw new InvalidDataException("无法识别正式版本号。");var result=new ReleaseInfo{Tag=tag,Version=v,VersionText=v.Major+"."+v.Minor+"."+v.Build+(v.Revision>0?"."+v.Revision:""),Page=Repo+"/releases/tag/"+Uri.EscapeDataString(tag),Notes=S(a,"body")};
  object assets;var list=a.TryGetValue("assets",out assets)?assets as IEnumerable:null;if(list==null)return result;
  string expected="Feng_C_Practice_ver"+result.VersionText+".exe",chinese="Feng_C语言练习器_ver"+result.VersionText+".exe";
  foreach(object item in list){var asset=item as IDictionary<string,object>;if(asset==null||S(asset,"state")!="uploaded")continue;string name=S(asset,"name"),url=S(asset,"browser_download_url");if(!AssetUrl(url,tag,name))continue;if(name=="SHA256SUMS.txt")result.ChecksumUrl=url;if(name!=expected&&name!=chinese)continue;long size;if(!long.TryParse(S(asset,"size"),out size)||size<1024||size>100*1024*1024)continue;result.Name=name;result.Download=url;result.Size=size;string hash=S(asset,"digest");if(Regex.IsMatch(hash,@"^sha256:[0-9a-fA-F]{64}$"))result.Sha256=hash.Substring(7).ToLowerInvariant();}
  return result;
 }
 public static bool AssetUrl(string url,string tag,string name){Uri u;return Uri.TryCreate(url,UriKind.Absolute,out u)&&u.Scheme=="https"&&u.Host=="github.com"&&u.IsDefaultPort&&u.UserInfo==""&&u.Query==""&&u.Fragment==""&&Uri.UnescapeDataString(u.AbsolutePath)=="/relsx/feng-c-practice/releases/download/"+tag+"/"+name;}
 public static bool AllowedUri(Uri u){if(u.Scheme!="https"||!u.IsDefaultPort||u.UserInfo!="")return false;return new[]{"api.github.com","github.com","release-assets.githubusercontent.com","objects.githubusercontent.com","github-releases.githubusercontent.com"}.Contains(u.Host,StringComparer.OrdinalIgnoreCase);}
 static async Task<HttpWebResponse> Open(Uri uri,CancellationToken ct){for(int redirect=0;redirect<6;redirect++){ct.ThrowIfCancellationRequested();if(!AllowedUri(uri))throw new InvalidDataException("更新下载地址不受信任。");var request=(HttpWebRequest)WebRequest.Create(uri);request.AllowAutoRedirect=false;request.Timeout=15000;request.ReadWriteTimeout=15000;request.UserAgent="Feng-C-Practice/1.2.1.2";request.Accept=uri.Host=="api.github.com"?"application/vnd.github+json":"application/octet-stream";if(uri.Host=="api.github.com")request.Headers["X-GitHub-Api-Version"]="2026-03-10";HttpWebResponse response;using(ct.Register(()=>request.Abort())){try{response=(HttpWebResponse)await request.GetResponseAsync().ConfigureAwait(false);}catch(WebException ex){if(ct.IsCancellationRequested)throw new OperationCanceledException(ct);var error=ex.Response as HttpWebResponse;if(error!=null){int code=(int)error.StatusCode;error.Dispose();if(code==403||code==429)throw new IOException("GitHub请求受限，请稍后重试。");if(code==404)throw new IOException("仓库暂未提供正式Release。");}throw new IOException("无法连接GitHub，请检查网络后重试。",ex);}}
    int status=(int)response.StatusCode;if(status>=300&&status<400){string location=response.Headers["Location"];response.Dispose();if(string.IsNullOrEmpty(location))throw new IOException("更新地址重定向无效。");uri=new Uri(uri,location);continue;}if(status!=200){response.Dispose();throw new IOException("GitHub返回异常状态。");}return response;}throw new IOException("更新地址重定向次数过多。");}
 static async Task<byte[]> GetBytes(string url,int limit,CancellationToken ct){using(var response=await Open(new Uri(url),ct).ConfigureAwait(false))using(var stream=response.GetResponseStream())using(var ms=new MemoryStream()){await Copy(stream,ms,limit,-1,null,ct).ConfigureAwait(false);return ms.ToArray();}}
 static async Task Copy(Stream input,Stream output,long limit,long expected,IProgress<int> progress,CancellationToken ct){byte[] buffer=new byte[65536];long total=0;while(true){ct.ThrowIfCancellationRequested();var read=input.ReadAsync(buffer,0,buffer.Length,ct);if(await Task.WhenAny(read,Task.Delay(15000,ct)).ConfigureAwait(false)!=read){ct.ThrowIfCancellationRequested();input.Dispose();throw new IOException("下载超时，请重试。");}int n=await read.ConfigureAwait(false);if(n==0)break;total+=n;if(total>limit)throw new InvalidDataException("下载内容超出允许大小。");await output.WriteAsync(buffer,0,n,ct).ConfigureAwait(false);if(progress!=null&&expected>0)progress.Report((int)Math.Min(100,total*100/expected));}if(expected>=0&&total!=expected)throw new InvalidDataException("下载大小与Release信息不符，请重新下载。");}
 public static Task Check(bool force=false){lock(gate){if(currentCheck!=null&&!currentCheck.IsCompleted)return currentCheck;currentCheck=CheckCore(force);return currentCheck;}}
 static async Task CheckCore(bool force){Checking=true;Notify();try{Directory.CreateDirectory(Root);string file=Path.Combine(Root,"release-cache.json");if(!force&&File.Exists(file)&&DateTime.UtcNow-File.GetLastWriteTimeUtc(file)<TimeSpan.FromHours(6)){Latest=Parse(File.ReadAllText(file));CheckedAt=File.GetLastWriteTime(file);}else{using(var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(25))){string raw=Encoding.UTF8.GetString(await GetBytes(Api,2097152,timeout.Token).ConfigureAwait(false));var parsed=Parse(raw);Latest=parsed;CheckedAt=DateTime.Now;try{File.WriteAllText(file,raw,new UTF8Encoding(false));}catch{}}}Status=Latest.Newer?"发现新版本 ver"+Latest.VersionText+" · 请在设置中一键更新":Latest.Version==Current?"当前已是最新正式版本":"当前本地版本高于已发布版本 ver"+Latest.VersionText;
  }catch(OperationCanceledException){Status="检查更新超时，离线练习仍可继续。";}catch(Exception ex){Status="检查未完成："+ex.Message;}finally{Checking=false;Notify();}}
 static void Notify(){var handler=Changed;if(handler!=null)handler();}
 public static string HashFile(string path){using(var s=File.OpenRead(path))using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(s)).Replace("-","").ToLowerInvariant();}
 public static string ParseChecksum(string text,string name){foreach(string line in text.Split('\n')){var m=Regex.Match(line.Trim(),@"^([0-9a-fA-F]{64})[ \t]+\*?(.+)$");if(m.Success&&m.Groups[2].Value==name)return m.Groups[1].Value.ToLowerInvariant();}throw new InvalidDataException("校验文件中未找到对应EXE。");}
 public static void Verify(string path,string sha,long size,Version version){var info=new FileInfo(path);if(info.Length!=size||!Regex.IsMatch(sha??"",@"^[0-9a-fA-F]{64}$")||!string.Equals(HashFile(path),sha,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("SHA-256校验失败，未安装更新。");using(var stream=File.OpenRead(path)){if(stream.ReadByte()!=77||stream.ReadByte()!=90)throw new InvalidDataException("下载的文件不是Windows程序。");}var f=FileVersionInfo.GetVersionInfo(path);Version actual;if(!TryVersion(f.FileVersion,out actual)||actual!=version)throw new InvalidDataException("EXE版本与Release版本不符，未安装更新。");}
 public static async Task<string> Download(ReleaseInfo release,IProgress<int> progress,CancellationToken ct){if(release==null||release.Version==null||string.IsNullOrEmpty(release.Download)||release.Size<=0||!AssetUrl(release.Download,release.Tag,release.Name))throw new InvalidOperationException("没有可下载的正式版EXE。");string dir=Path.Combine(Root,"ver"+release.VersionText+"-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);string target=Path.Combine(dir,release.Name),part=target+".part";try{string hash=release.Sha256;if(string.IsNullOrEmpty(hash)){if(string.IsNullOrEmpty(release.ChecksumUrl)||!AssetUrl(release.ChecksumUrl,release.Tag,"SHA256SUMS.txt"))throw new InvalidDataException("Release缺少SHA-256校验信息。");hash=ParseChecksum(Encoding.UTF8.GetString(await GetBytes(release.ChecksumUrl,262144,ct).ConfigureAwait(false)),release.Name);}using(var response=await Open(new Uri(release.Download),ct).ConfigureAwait(false))using(var input=response.GetResponseStream())using(var output=new FileStream(part,FileMode.CreateNew,FileAccess.Write,FileShare.None,65536,true)){await Copy(input,output,release.Size,release.Size,progress,ct).ConfigureAwait(false);}Verify(part,hash,release.Size,release.Version);ct.ThrowIfCancellationRequested();File.Move(part,target);release.Sha256=hash;return target;}catch{try{if(File.Exists(part))File.Delete(part);}catch{}throw;}}
 public static bool CanRestart{get{var app=System.Windows.Application.Current;if(app==null)return true;return !app.Windows.OfType<MainWindow>().Any(x=>x.IsEvaluating)&&!app.Windows.OfType<ChallengeWindow>().Any(x=>x.IsAttemptRunning);}}
 public static void PrepareAndRestart(string downloaded,ReleaseInfo release){UpdateInstaller.Start(downloaded,release);}
 public static int Apply(string manifest){return UpdateInstaller.Apply(manifest,false);}
 public static int ApplyElevated(string manifest){return UpdateInstaller.Apply(manifest,true);}
}
